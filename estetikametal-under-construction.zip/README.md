# Estetika Metal - Under Construction Website

Upload these files to GitHub:
- index.html
- style.css
- assets/hero.jpg

Important:
Replace assets/hero.jpg with the final image of the worker/hammer on metal.
The page already contains phone number: +381 63 719 0177.
